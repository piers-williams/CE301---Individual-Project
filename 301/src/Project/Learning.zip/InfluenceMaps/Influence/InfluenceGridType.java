package Learning.InfluenceMaps.Influence;

/**
 * Created with IntelliJ IDEA.
 * User: Piers
 * Date: 29/10/12
 * Time: 10:16
 * To change this template use File | Settings | File Templates.
 */
public enum InfluenceGridType {
    SimpleSquare;
}
