package Learning.TransparentDistributedComputeThread;

/**
 * Created by IntelliJ IDEA.
 * User: Piers
 * Date: 01/05/12
 * Time: 21:11
 */
public class InnerNode {

    public static void main(String[] args) {

    }
}
