package Learning.TransparentDistributedComputeThread;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: Piers
 * Date: 01/05/12
 * Time: 21:30
 */
public class Response implements Serializable{


}
