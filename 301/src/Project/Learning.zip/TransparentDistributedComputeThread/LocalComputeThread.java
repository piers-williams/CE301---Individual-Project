package Learning.TransparentDistributedComputeThread;

import java.util.PriorityQueue;
import java.util.Queue;

/**
 * Created by IntelliJ IDEA.
 * User: Piers
 * Date: 01/05/12
 * Time: 21:34
 */
public class LocalComputeThread implements Runnable {


    public LocalComputeThread(){

    }

    public void run() {

    }

    public void addTask(Task input){

    }
}
