package PhaseA.Test;

import PhaseA.Map.Map;
import PhaseA.Map.MapReader;
import PhaseA.Viewer;

import javax.swing.*;
import java.io.File;

/**
 * Created by IntelliJ IDEA.
 * User: Piers
 * Date: 10/05/12
 * Time: 22:36
 */
public class MapReaderTest {

    public static void main(String[] args) {
        MapReader mapReader = new MapReader(new File("Content/Maps/Normal"));

        JFrame frame = new JFrame("MapReaderTest");

        Map map = mapReader.readMap();
        frame.add(new Viewer(map));
        frame.setDefaultCloseOperation(3);
        frame.setVisible(true);

        frame.pack();
    }
}
