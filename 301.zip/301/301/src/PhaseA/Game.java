package PhaseA;

import PhaseA.Map.Map;

import javax.swing.*;
import java.awt.*;

/**
 * Created by IntelliJ IDEA.
 * User: Piers
 * Date: 09/05/12
 * Time: 12:41
 */
public class Game {
    Map map;
    Viewer viewer;

    public Game() {

        map = new Map(100, 80);
        viewer = new Viewer(map);
    }

    public Viewer getViewer() {
        return viewer;
    }

    public void update(){

    }

    public void draw(){

    }

    public static void main(String[] args) {
        Game game = new Game();
        JFrame frame = new JFrame("Game");
        frame.add(game.getViewer(), BorderLayout.CENTER);

        frame.setDefaultCloseOperation(3);
        frame.setVisible(true);
        frame.pack();
    }
}
