package PhaseA;

import PhaseA.Map.Map;

import javax.swing.*;
import java.awt.*;

/**
 * Created by IntelliJ IDEA.
 * User: Piers
 * Date: 09/05/12
 * Time: 12:43
 */
public class Viewer extends JComponent {
    // Location of Viewer
    private int x, y;

    // Width and height of the Viewer
    private int width = 100, height = 80;


    private Map map;

    public Viewer(Map map) {
        this.map = map;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);    //To change body of overridden methods use File | Settings | File Templates.

        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                g.drawImage(
                        map.getTile(i, j).getImage(),
                        i * 10,
                        j * 10,
                        Color.WHITE,
                        null
                );
            }
        }
    }

    public void moveUp() {
        y--;
    }

    public void moveDown() {
        y++;
    }

    public void moveLeft() {
        x--;
    }

    public void moveRight() {
        x++;
    }

    @Override
    public Dimension getPreferredSize() {
        return (new Dimension(1000, 800));
    }
}
