package PhaseA.Map;

import java.awt.image.BufferedImage;

/**
 * Created by IntelliJ IDEA.
 * User: Piers
 * Date: 10/05/12
 * Time: 22:27
 */
public final class TileStat {

    private int red, green, blue;
    private int rgb;

    private BufferedImage image;

    public TileStat(int red, int green, int blue, BufferedImage image) {
        this.red = red;
        this.green = green;
        this.blue = blue;

        rgb = red * 10000 + green * 100 + blue;
        this.image = image;
    }

    public int getRgb() {
        return rgb;
    }

    public BufferedImage getImage() {
        return image;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TileStat tileStat = (TileStat) o;

        if (blue != tileStat.blue) return false;
        if (green != tileStat.green) return false;
        if (red != tileStat.red) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = red;
        result = 31 * result + green;
        result = 31 * result + blue;
        return result;
    }

    @Override
    public String toString() {
        return "TileStat{" +
                "red=" + red +
                ", green=" + green +
                ", blue=" + blue +
                ", rgb=" + rgb +
                ", image=" + image +
                '}';
    }
}
