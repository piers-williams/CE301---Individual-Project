package PhaseA.Map;

import java.awt.image.BufferedImage;

/**
 * Created by IntelliJ IDEA.
 * User: Piers
 * Date: 08/05/12
 * Time: 15:44
 */
public class Tile {

    TileStat tileStat;

    public Tile(TileStat tileStat) {
        this.tileStat = tileStat;
    }

    public TileStat getTileStat() {
        return tileStat;
    }

    public BufferedImage getImage(){
        return tileStat.getImage();
    }
}
