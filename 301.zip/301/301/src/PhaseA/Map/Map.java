package PhaseA.Map;

/**
 * Created by IntelliJ IDEA.
 * User: Piers
 * Date: 08/05/12
 * Time: 15:52
 */
public class Map {

    private int width, height;
    Tile[][] tiles;

    public Map(int width, int height) {

        this.height = height;
        this.width = width;
        tiles = new Tile[height][width];
    }

    public void fillAll(TileStat tileStat) {
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                tiles[y][x] = new Tile(tileStat);
            }
        }
    }

    public void fillEmpty(TileStat tileStat) {
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                if (tiles[y][x] == null) {
                    tiles[y][x] = new Tile(tileStat);
                }
            }
        }
    }

    public void setTile(int x, int y, Tile input) {
        if (x < width && y < height) {
            tiles[y][x] = input;
        } else{
            System.out.println("Failed to add Tile");
        }
    }


    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public void setWidth(int width) {
        Tile[][] newTiles = new Tile[height][width];

        System.out.println("width: " + width + " mapWidth: " + tiles[0].length);
        if (width >= tiles[0].length) {
            for (int i = 0; i < tiles[0].length; i++) {
//                for (int j = 0; j < tiles[0].length; j++) {
//                    newTiles[i][j] = tiles[i][j];
//                }
                System.arraycopy(tiles[i], 0, newTiles[i], 0, tiles[i].length);
            }
        } else {
            // Loop through all rows
            for (int i = 0; i < tiles.length; i++) {
                // Copy only so wide
                System.arraycopy(tiles[i], 0, newTiles[i], 0, width);
            }
        }
        tiles = newTiles;
        this.width = width;
    }

    public void setHeight(int height) {
        Tile[][] newTiles = new Tile[height][width];

        if (height >= tiles.length) {
            for (int i = 0; i < tiles.length; i++) {
                System.arraycopy(tiles[i], 0, newTiles[i], 0, tiles[i].length);
            }
        } else {
            for (int i = 0; i < height; i++) {
                System.arraycopy(tiles[i], 0, newTiles[i], 0, tiles[i].length);
            }
        }
        tiles = newTiles;
        this.height = height;

    }

    public Tile getTile(int x, int y) {
        return (tiles[y][x]);
    }
}
