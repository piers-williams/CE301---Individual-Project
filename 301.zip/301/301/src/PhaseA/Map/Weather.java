package PhaseA.Map;

/**
 * Created by IntelliJ IDEA.
 * User: Piers
 * Date: 08/05/12
 * Time: 15:49
 */
public enum Weather {

    Normal(1),
    Snow(0.5),
    Rain(0.9);

    private double movementFactor;

    Weather(double movementFactor){
        this.movementFactor = movementFactor;
    }

    public double getMovementFactor(){
        return movementFactor;
    }
}
