package PhaseA.Map;

import PhaseA.Utilities.Constants;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.imageio.ImageIO;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;

/**
 * Created by IntelliJ IDEA.
 * User: Piers
 * Date: 10/05/12
 * Time: 21:27
 */
public class MapReader {

    MapParser parser;
    MapPixelReader pixelReader;

    public MapReader(File mapDirectory) {
        parser = new MapParser(mapDirectory.getAbsolutePath() + "/tiles.xml");
        pixelReader = new MapPixelReader(mapDirectory.getAbsolutePath() + "/map.png", parser.parse());
    }

    public Map readMap() {
        return (pixelReader.generateMap());
    }
}

class MapParser {

    DocumentBuilderFactory documentBuilderFactory;
    Document dom;

    public MapParser(String fileName) {
        documentBuilderFactory = DocumentBuilderFactory.newInstance();

        try {
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            dom = documentBuilder.parse(new File(fileName));


        } catch (ParserConfigurationException pce) {
        } catch (SAXException saxe) {

        } catch (IOException ioe) {

        }
    }

    public HashMap<Integer, TileStat> parse() {

        HashMap<Integer, TileStat> tiles = new HashMap<Integer, TileStat>();

        Element root = dom.getDocumentElement();

        NodeList nodeList = root.getElementsByTagName("Tile");

        System.out.println(nodeList.getLength());
        if (nodeList != null && nodeList.getLength() > 0) {
            for (int i = 0; i < nodeList.getLength(); i++) {
                Element tile = (Element) nodeList.item(i);

                TileStat tileStat = elementToTileStat(tile);
                tiles.put(tileStat.getRgb(), tileStat);
            }
        } else {
            System.err.println("No Tiles");
        }

        return (tiles);
    }

    private TileStat elementToTileStat(Element element) {
        int red, green, blue;

        red = getIntValue(element, "Red");
        green = getIntValue(element, "Green");
        blue = getIntValue(element, "Blue");

        try {

            String fileName = Constants.tileImgLocations + getStringValue(element, "ImageSource");
//            System.out.println(fileName);
            BufferedImage image = ImageIO.read(new File(fileName));
            TileStat tileStat = new TileStat(red, green, blue, image);
//            System.out.println(tileStat);
            return (tileStat);

        } catch (IOException ioe) {
            System.err.println("Couldn't load tile image");
        }

        return null;
    }

    private int getIntValue(Element element, String tag) {
        NodeList nodeList = element.getElementsByTagName(tag);

        if (nodeList != null && nodeList.getLength() > 0) {
            Element information = (Element) nodeList.item(0);
            return (Integer.parseInt(information.getFirstChild().getNodeValue()));
        } else {
            return 0;
        }
    }

    private String getStringValue(Element element, String tag) {
        NodeList nodeList = element.getElementsByTagName(tag);

        if (nodeList != null && nodeList.getLength() > 0) {
            Element information = (Element) nodeList.item(0);
            return (information.getFirstChild().getNodeValue());
        } else {
            return "";
        }
    }
}

class MapPixelReader {

    private BufferedImage image;
    private HashMap<Integer, TileStat> tileStats;

    public MapPixelReader(String fileName, HashMap<Integer, TileStat> tileStats) {
        try {
            image = ImageIO.read(new File(fileName));
            this.tileStats = tileStats;
        } catch (IOException ioe) {
            System.err.println("Couldn't find file: " + fileName);
        }
    }

    public Map generateMap() {
        Map map = new Map(width(), height());

        for (int x = 0; x < width(); x++) {
//            System.out.println();
            for (int y = 0; y < height(); y++) {
                int argb = image.getRGB(x, y);
                int rgb[] = new int[]{
                        (argb >> 16) & 0xff, //red
                        (argb >> 8) & 0xff, //green
                        (argb) & 0xff  //blue
                };
                int finalKey = rgb[0] * 10000 + rgb[1] * 100 + rgb[2];
//                System.out.print(argb + "," + finalKey + " :: ");
                map.setTile(x, y, new Tile(tileStats.get(finalKey)));
            }
        }
        return map;
    }

    public int[] getRGB(int x, int y) {
        if (x < width() && y < height()) {
            int argb = image.getRGB(x, y);

            return new int[]{
                    (argb >> 16) & 0xff,
                    (argb >> 8) & 0xff,
                    (argb) & 0xff
            };
        } else {
            return new int[]{0, 0, 0};
        }
    }

    public int width() {
        return image.getWidth();
    }

    public int height() {
        return image.getHeight();
    }

    public boolean available() {
        return (image != null);
    }

}