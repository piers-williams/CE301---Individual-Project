package PhaseA.Utilities;

/**
 * Created by IntelliJ IDEA.
 * User: Piers
 * Date: 09/05/12
 * Time: 13:44
 */
public class Constants {

    public static final String tileImgLocations = "Content/Images/TileTextures/";


}
