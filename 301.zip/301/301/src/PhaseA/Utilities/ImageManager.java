package PhaseA.Utilities;

import java.awt.image.BufferedImage;
import java.util.HashMap;

/**
 * Created by IntelliJ IDEA.
 * User: Piers
 * Date: 09/05/12
 * Time: 13:33
 */
public class ImageManager {

    private HashMap<String, BufferedImage> images;

    public ImageManager() {

        images = new HashMap<String, BufferedImage>();
    }

    public BufferedImage getImage(String key){
        String processedKey = normalisedString(key);
        if(images.containsKey(processedKey)){
           return (images.get(normalisedString(key)));
        }else{
            throw new ImageNotFound(processedKey);
        }
    }

    private String normalisedString(String input){
        return (input.toLowerCase());
    }
}

class ImageNotFound extends RuntimeException{
       private String data;

    ImageNotFound(String data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "ImageNotFound{" +
                "data='" + data + '\'' +
                '}';
    }
}
