package PhaseA.Threads;

import PhaseA.Game;

/**
 * Created by IntelliJ IDEA.
 * User: Piers
 * Date: 09/05/12
 * Time: 13:46
 */
public class GameThread implements Runnable {

    Game game;
    long startTime;
    long finishTime;


    public void run() {
        while (true) {
            game.update();
            game.draw();
            try {
                Thread.sleep(20);
            } catch (InterruptedException ie) {
                System.err.println("Thread Interrupted");
            }
        }
    }
}
