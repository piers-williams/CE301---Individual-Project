package MapEditor;

import PhaseA.Map.Map;
import PhaseA.Map.Tile;
import PhaseA.Map.TileStat;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: Piers
 * Date: 11/05/12
 * Time: 09:30
 */
public class Editor extends JFrame {

    MapViewer mapViewer;
    Map map = new Map(10, 10);
    TileChooser tileChooser;
    TileSet tileSet;

    int red = 0, green = 0, blue = 0;


    public Editor() {

        // Initialise and Populate the TileSet0
        tileSet = new TileSet();
        populateTileSet();

        // Initialise the Tile Chooser
        tileChooser = new TileChooser(tileSet);

        // Initialise Map to a StartTile
        map.fillAll(tileSet.get(1));

        // Initialise the Map Viewer
        mapViewer = new MapViewer(map);
        mapViewer.addMouseListener(new MapMouseAdapter(tileChooser, map, mapViewer));

        /*

        Left panel will host the various tileSets at the top half, with the corresponding tiles in the bottom half

        Right panel will control other things
        Bottom panel will contain information about which tile is clicked
         */
        /*
        Tile Panel
         */
        JPanel leftPanel = new JPanel();
        JPanel tileSets = new JPanel();
        JPanel tileSpecifics = new JPanel();

        leftPanel.setLayout(new GridLayout(2, 1));
        leftPanel.setPreferredSize(new Dimension(200, 800));
        /*
        Tile Sets panel
         */
        tileSets.setPreferredSize(new Dimension(200, 400));
        tileSets.setBorder(BorderFactory.createEtchedBorder());
        leftPanel.add(tileSets);

        /*
        Tile Specifics Panel
         */
        tileSpecifics.setPreferredSize(new Dimension(200, 400));
        tileSpecifics.setBorder(BorderFactory.createEtchedBorder());
        tileSpecifics.add(tileChooser);

        leftPanel.add(tileSpecifics);

        /*
        Map Panel
        */
        Box rightPanel = Box.createVerticalBox();
        rightPanel.setBorder(BorderFactory.createEtchedBorder());
        rightPanel.setPreferredSize(new Dimension(200, 800));

        final JSlider heightSlider = new JSlider(10, 500, 100);
        final JSlider widthSlider = new JSlider(10, 500, 100);
        final JLabel heightLabel = new JLabel("100");
        final JLabel widthLabel = new JLabel("100");


        heightSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {

                heightLabel.setText(Integer.toString(heightSlider.getValue()));
                JSlider source = (JSlider) e.getSource();
                if (!source.getValueIsAdjusting()) {
                    map.setHeight(heightSlider.getValue());
                    map.fillEmpty(tileSet.get(0));

                    repaint();
                }
            }
        });
        widthSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                widthLabel.setText(Integer.toString(widthSlider.getValue()));
                JSlider source = (JSlider) e.getSource();
                if (!source.getValueIsAdjusting()) {
                    map.setWidth(widthSlider.getValue());
                    map.fillEmpty(tileSet.get(0));

                    repaint();
                }
            }
        });

        rightPanel.add(Box.createVerticalGlue());
        rightPanel.add(new JLabel("Set the height:"));
        rightPanel.add(heightLabel);
        rightPanel.add(heightSlider);
        rightPanel.add(new JLabel("Set the width: "));
        rightPanel.add(widthSlider);
        rightPanel.add(widthLabel);
        rightPanel.add(Box.createVerticalGlue());

        /*
       MenuBar
        */
        setUpMenu();

        /*
        Frame stuff
         */
//        this.add(dummyMapViewer, BorderLayout.CENTER);
        this.add(mapViewer, BorderLayout.CENTER);
        this.add(leftPanel, BorderLayout.LINE_START);
        this.add(rightPanel, BorderLayout.LINE_END);

        setTitle("MapEditor");
        setDefaultCloseOperation(3);

        setVisible(true);
        pack();
    }

    private void populateTileSet() {
        try {
            File contentDirectory = new File("Content/Images/TileTextures");
            for (File texture : contentDirectory.listFiles()) {
                red++;
                if (red == 255) {
                    red = 0;
                    green++;
                }
                if (green == 255) {
                    green = 0;
                    blue++;
                }
                if (blue == 255) {
                    blue = 0;
                }

                tileSet.add(new TileStat(red, green, blue, ImageIO.read(texture)));
            }
        } catch (IOException ioe) {

        }
    }

    private void setUpMenu() {

        JMenuBar menuBar = new JMenuBar();

        JMenu menu = new JMenu("File");
        menuBar.add(menu);

        menu = new JMenu("Tile");
        menuBar.add(menu);

        setJMenuBar(menuBar);
    }

    public static void main(String[] args) {
        Editor editor = new Editor();
    }
}

class TileChooser extends JComponent {

    int width = 6, height;
    int tileGap = 15;
    int tileWidth = 10, tileHeight = 10;
    int startY = 25, startX = 5;

    TileSet currentTileSet;

    TileStat currentTileStat;


    public TileChooser(TileSet currentTileSet) {
        addMouseListener(new TileChooserMouseAdapter(this));

        this.currentTileSet = currentTileSet;
        currentTileStat = currentTileSet.get(0);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);    //To change body of overridden methods use File | Settings | File Templates.
        if (currentTileSet != null) {
            // Number of complete rows possible (Integer division) + 1 row for incomplete row
            height = (currentTileSet.size() / width) + 1;
            // Index for accessing the Tiles, can't use the loop as they are for drawing
            int index = 0;


            drawLoop:
            for (int y = startY; y < ((tileHeight + tileGap) * height) + startY; y += tileGap) {
                for (int x = startX; x < ((tileWidth + tileGap) * width) + startX; x += tileGap) {

                    if (index == currentTileSet.size()) {
                        break drawLoop;
                    }
                    g.drawImage(
                            currentTileSet.get(index).getImage(),
                            x,
                            y,
                            null
                    );
                    index++;
                }
            }

            g.drawImage(currentTileStat.getImage(), 5, 5, null);
        } else {
            g.setColor(Color.DARK_GRAY);
            g.fill3DRect(0, 0, 100, 400, true);
        }
    }

    @Override
    public Dimension getPreferredSize() {
        return (new Dimension(200, 400));
    }

    private void setCurrentTileSet(TileSet tileSet) {
        this.currentTileSet = tileSet;
    }

    protected void click(int x, int y) {
        int newX = x, newY = y;

        newX -= startX;
        newY -= startY;

        newX /= (tileGap);
        newY /= (tileGap);

        currentTileStat = currentTileSet.get((newX + (height * newY)));
        repaint();
    }

    public TileStat getCurrentTileStat() {
        return currentTileStat;
    }
}

class TileChooserMouseAdapter extends MouseAdapter {

    TileChooser chooser;

    TileChooserMouseAdapter(TileChooser chooser) {
        this.chooser = chooser;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        super.mouseClicked(e);

        chooser.click(e.getX(), e.getY());


    }
}

class MapMouseAdapter extends MouseAdapter {

    TileChooser chooser;
    Map map;
    MapViewer mapViewer;
    ArrayList<Point> points;

    boolean down;

    MapMouseAdapter(TileChooser chooser, Map map, MapViewer mapViewer) {
        this.chooser = chooser;
        this.map = map;
        this.mapViewer = mapViewer;
//        down = false;

//        points = new ArrayList<Point>(200);
    }

//    @Override
//    public void mousePressed(MouseEvent e) {
//        super.mousePressed(e);    //To change body of overridden methods use File | Settings | File Templates.
//        down = true;
//        points = new ArrayList<Point>(200);
//        points.add(new Point(screenToMapX(e.getX()), screenToMapY(e.getY())));
//    }

    @Override
    public void mouseDragged(MouseEvent e) {
        map.setTile(screenToMapX(e.getX()), screenToMapY(e.getY()), new Tile(chooser.getCurrentTileStat()));
        mapViewer.repaint();
    }

//    @Override
//    public void mouseReleased(MouseEvent e) {
//        down = false;
//        // add all the points here
//    }

    @Override
    public void mouseClicked(MouseEvent e) {
        super.mouseClicked(e);
//        System.out.println("Mouse Clicked" + e.getX() + " , " + e.getY());
        // Will also later on need to factor in the ability to scroll the screen
        //  rather than use direct screen co-ordinates
        map.setTile(screenToMapX(e.getX()), screenToMapY(e.getY()), new Tile(chooser.getCurrentTileStat()));
        mapViewer.repaint();
    }

    private int screenToMapX(int screenX) {
        return (screenX / 10);
    }

    private int screenToMapY(int screenY) {
        return (screenY / 10);
    }
}
