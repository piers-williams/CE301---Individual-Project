package MapEditor;

import PhaseA.Map.Map;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/**
 * Created by IntelliJ IDEA.
 * User: Piers
 * Date: 11/05/12
 * Time: 09:31
 */
public class MapViewer extends JComponent {

    Map map;

    int width = 100, height = 80;

    public MapViewer() {

        map = new Map(100, 80);
    }

    public MapViewer(Map map) {
        this.map = map;

        this.width = map.getWidth();
        this.height = map.getHeight();
    }

    public void update() {
        this.width = map.getWidth();
        this.height = map.getHeight();
    }

    @Override
    protected void paintComponent(Graphics g) {
        for (int i = 0; i < map.getWidth(); i++) {
            for (int j = 0; j < map.getHeight(); j++) {
                g.drawImage(
                        map.getTile(i, j).getImage(),
                        i * 10,
                        j * 10,
                        Color.WHITE,
                        null
                );
            }
        }
    }

    @Override
    public Dimension getPreferredSize() {
        return (new Dimension(1000, 800));
    }
}

class MapMouseListener implements MouseListener {

    public void mouseClicked(MouseEvent e) {

    }

    public void mousePressed(MouseEvent e) {

    }

    public void mouseReleased(MouseEvent e) {

    }

    public void mouseEntered(MouseEvent e) {

    }

    public void mouseExited(MouseEvent e) {

    }
}
