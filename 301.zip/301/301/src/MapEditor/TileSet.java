package MapEditor;

import PhaseA.Map.TileStat;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: Piers
 * Date: 11/05/12
 * Time: 12:00
 */
public class TileSet implements Iterable<TileStat> {

    private ArrayList<TileStat> tiles = new ArrayList<TileStat>();

    public TileSet() {

    }

    public void add(TileStat input) {
        tiles.add(input);
    }

    public TileStat get(int index) {
        return tiles.get(index);
    }

    public int size(){
        return tiles.size();
    }

    public Iterator<TileStat> iterator() {
        return new Iterator<TileStat>() {
            int index = 0;

            public boolean hasNext() {
                return (tiles.get(index + 1) == null);
            }

            public TileStat next() {
                index++;
                return (tiles.get(index));
            }

            public void remove() {

            }
        };
    }
}
