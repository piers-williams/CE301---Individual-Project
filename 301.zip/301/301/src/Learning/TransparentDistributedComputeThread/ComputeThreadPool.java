package Learning.TransparentDistributedComputeThread;

/**
 * Created by IntelliJ IDEA.
 * User: Piers
 * Date: 01/05/12
 * Time: 21:35
 */
public class ComputeThreadPool {

    LocalComputeThread[] threads;

    public ComputeThreadPool() {
    }


}
